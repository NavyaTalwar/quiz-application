import React from "react"

const Home = () => {
	return (
		<main>
			<h2 className="mt-5">Welcome to online quiz for everyone</h2>
		</main>
	)
}

export default Home
